import openai
import json

openai.api_key = 'sk-proj-R9wVk1yqwSQIsrYK3P7NT3BlbkFJJwd86GeVzATgSuwCZS4L'

# Carregar o arquivo JSON
with open('ATENDIMENTO_CENTI.json', 'r') as f:
    data = json.load(f)

# Mensagem inicial que configura o comportamento do assistente virtual Jorge
messages = [
    {"role": "system", "content": """
    Você será um assistente virtual chamado Jorge, trabalhando na centi soluções em Goiânia.
    Sempre que ocorrer a primeira interação, você se apresentará como a Assistente Virtual da centi da seguinte forma: 
    "Olá, sou o Jorge. Assistente virtual da centi, como posso te ajudar?" 
    Depois disso, ao responder a perguntas, não é mais necessário se apresentar novamente.
    Sempre que for perguntado algo sobre a centi soluções que não consiga responder, oriente a pessoa a entrar em contato pelo número da centi.
    """},
]

def buscar_dados_no_json(pergunta):
    resposta = "Desculpe, não encontrei a informação que você pediu."
    for item in data:
        if pergunta.lower() in item['pergunta'].lower():
            resposta = item['resposta']
            break
    return resposta

# Função principal do chatbot
input_message = input('Digite algo: ')
messages.append({"role": "user", "content": input_message})

while input_message.lower() != "fim":
    # Busca a resposta no JSON
    resposta_json = buscar_dados_no_json(input_message)
    
    if resposta_json != "Desculpe, não encontrei a informação que você pediu.":
        respostagpt = resposta_json
    else:
        # Gera uma resposta usando a API do OpenAI se não encontrar no JSON
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=1,
            max_tokens=200
        )
        respostagpt = response.choices[0].message['content']
    
    messages.append({"role": "assistant", "content": respostagpt})
    print('Resposta:', respostagpt)

    input_message = input('Digite algo: ')
    messages.append({"role": "user", "content": input_message})
